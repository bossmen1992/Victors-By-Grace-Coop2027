# Victors By Grace Coop2027 — Android Studio project

This project wraps the existing cooperative tracker HTML app in an Android WebView.
It is a buildable project source, not a prebuilt APK.

## Build an APK
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK output location (usually app/build/outputs/apk/debug/app-debug.apk).

## Important data note
The tracker uses browser localStorage inside the app. Keep the app installed and do not clear its app data.
Uninstalling the app or clearing its storage may erase locally saved records. Make a backup/export if the tracker provides one before replacing or uninstalling the app.
