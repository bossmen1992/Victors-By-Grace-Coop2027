VICTORS BY GRACE COOP2027 — BUILD APK USING ONLY AN ANDROID PHONE

This is Android project source plus a GitHub Actions workflow. It is NOT an APK yet.
GitHub's free Actions service can build the APK online after the project is uploaded to a GitHub repository.

PHONE STEPS (may vary slightly by GitHub app/browser version):
1. Sign in or create an account at https://github.com using Chrome.
2. Create a NEW repository named VictorsByGraceCoop2027. Choose Private if you want the source kept private.
3. Extract this ZIP on your phone using Files/My Files. Upload the CONTENTS of the extracted project (including the hidden .github/workflows/build-apk.yml folder) into the repository's main branch. If the GitHub mobile interface cannot upload folders or hidden files, use Chrome's Desktop site or a ZIP upload workflow that preserves folders.
4. Open the repository's Actions tab.
5. Select “Build Victors By Grace Coop2027 APK”, then tap “Run workflow”.
6. Wait for the workflow to finish successfully. Open the completed run and download the artifact named “VictorsByGraceCoop2027-APK”.
7. Extract the downloaded artifact ZIP. Tap app-debug.apk to install. Android may ask permission to install unknown apps; only enable it for the browser/file manager you used, then turn it off afterward.

IMPORTANT:
- Do not share your GitHub password or verification codes with anyone.
- The APK is unsigned for Play Store distribution; it is intended for personal installation/testing.
- App data is stored locally on the phone. Uninstalling or clearing app storage can erase records.
- This workflow has not been run from this package yet, so an APK is not guaranteed until GitHub reports a successful build.
